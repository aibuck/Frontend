// 12개의 질문을 포함한 하나의 배열!
export const questioncontent = [{
  number: 1,
  question: "당신은 외향적인 E 입니까?, 내향적인 I 입니까?",
  answer1 : "외향적인 E",
  answer2 : "내향적인 I",
  type: "E"
},{
  number: 2,
  question: "당신은 현실적인 S 입니까?, 이상적인 N 입니까?",
  answer1 : "현실적인 S",
  answer2 : "직관적인 N",
  type: "S"
},{
  number: 3,
  question: "당신은 사고하는 T 입니까?, 감정적인 F 입니까?",
  answer1 : "사고하는 T",
  answer2 : "감정적인 F",
  type: "T"
},{
  number: 4,
  question: "당신은 계획하는 J 입니까?, 즉흥적인 P 입니까?",
  answer1 : "계획하는 J",
  answer2 : "즉흥적인 P",
  type: "J"
},{
  number: 5,
  question: "당신은 외향적인 E 입니까?, 내향적인 I 입니까?",
  answer1 : "외향적인 E",
  answer2 : "내향적인 I",
  type: "E"
},{
  number: 6,
  question: "당신은 현실적인 S 입니까?, 이상적인 N 입니까?",
  answer1 : "현실적인 S",
  answer2 : "직관적인 N",
  type: "S"
},{
  number: 7,
  question: "당신은 사고하는 T 입니까?, 감정적인 F 입니까?",
  answer1 : "사고하는 T",
  answer2 : "감정적인 F",
  type: "T"
},{
  number: 8,
  question: "당신은 계획하는 J 입니까?, 즉흥적인 P 입니까?",
  answer1 : "계획하는 J",
  answer2 : "즉흥적인 P",
  type: "J"
},{
  number: 9,
  question: "당신은 외향적인 E 입니까?, 내향적인 I 입니까?",
  answer1 : "외향적인 E",
  answer2 : "내향적인 I",
  type: "E"
},{
  number: 10,
  question: "당신은 현실적인 S 입니까?, 이상적인 N 입니까?",
  answer1 : "현실적인 S",
  answer2 : "직관적인 N",
  type: "S"
},{
  number: 11,
  question: "당신은 사고하는 T 입니까?, 감정적인 F 입니까?",
  answer1 : "사고하는 T",
  answer2 : "감정적인 F",
  type: "T"
},{
  number: 12,
  question: "당신은 계획하는 J 입니까?, 즉흥적인 P 입니까?",
  answer1 : "계획하는 J",
  answer2 : "즉흥적인 P",
  type: "J"
},{
  number: 1,
  question: "당신은 외향적인 E 입니까?, 내향적인 I 입니까?",
  answer1 : "외향적인 E",
  answer2 : "내향적인 I",
  type: "E"
},{
  number: 2,
  question: "당신은 현실적인 S 입니까?, 이상적인 N 입니까?",
  answer1 : "현실적인 S",
  answer2 : "직관적인 N",
  type: "S"
},{
  number: 3,
  question: "당신은 사고하는 T 입니까?, 감정적인 F 입니까?",
  answer1 : "사고하는 T",
  answer2 : "감정적인 F",
  type: "T"
},{
  number: 4,
  question: "당신은 계획하는 J 입니까?, 즉흥적인 P 입니까?",
  answer1 : "계획하는 J",
  answer2 : "즉흥적인 P",
  type: "J"
}]