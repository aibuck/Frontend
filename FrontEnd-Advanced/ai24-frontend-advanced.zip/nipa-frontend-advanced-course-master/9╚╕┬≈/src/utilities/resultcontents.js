// 16개의 성향을 포함한 하나의 배열!
export const resultcontent = [{
  type: "ISTJ",
  description: "한번 시작한 일은 끝까지 해내는 사람들"
},{
  type: "ISFJ",
  description: "성실하고 온화하며 협조를 잘하는 사람들"
},{
  type: "INFJ",
  description: "사람과 관련된 뛰어난 통찰력을 가지고 있는 사람들"
},{
  type: "INTJ",
  description: "전체적인 부분을 조합하여 비전을 제시하는 사람들"
},{
  type: "ISTP",
  description: "논리적이고 뛰어난 상황 적응력을 가지고 있는 사람들"
},{
  type: "ISFP",
  description: "따뜻한 감성을 가지고 있는 겸손한 사람들"
},{
  type: "INFP",
  description: "이상적인 세상을 만들어 가는 사람들"
},{
  type: "INTP",
  description: "비평적인 관점을 가지고 있는 뛰어난 전략가들"
},{
  type: "ESTP",
  description: "친구, 운동, 음식 등 다양한 활동을 선호하는 사람들"
},{
  type: "ESFP",
  description: "분위기를 고조시키는 우호적 사람들"
},{
  type: "ENFP",
  description: "열정적으로 새로운 관계를 만드는 사람들"
},{
  type: "ENTP",
  description: "풍부한 상상력을 가지고 새로운 것에 도전하는 사람들"
},{
  type: "ESTJ",
  description: "사무적, 실용적, 현실적으로 일을 많이 하는 사람들"
},{
  type: "ESFJ",
  description: "친절과 현실감을 바탕으로 타인에게 봉사하는 사람들"
},{
  type: "ENFJ",
  description: "타인의 성장을 도모하고 협동하는 사람들"
},{
  type: "ENTJ",
  description: "비전을 가지고 사람들을 활력적으로 이끌어가는 사람들"
}]