
const sayGoodbye = function(){
  console.log("good bye!")
}

const sayNice = function(){
  console.log("nice!")
}

module.exports = {
  sayGoodbye, sayNice
}