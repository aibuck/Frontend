const helloWorld = require("./mod1")
const {sayGoodbye, sayNice} = require("./mod2")

helloWorld()
sayGoodbye()
sayNice()