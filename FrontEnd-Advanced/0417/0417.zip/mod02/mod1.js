const helloWorld = () => {
  console.log("Hello world!")
}

module.exports = helloWorld