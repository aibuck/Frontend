const sayGoodbye = () => {
  console.log("good bye!")
}

const sayNice = () => {
  console.log("nice!")
}

module.exports = {
  sayGoodbye, sayNice
}