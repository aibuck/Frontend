const { sayHello, sayGoodbye } = require("./sub")//구조분해

sayHello()
sayGoodbye()